package com.rajan.foodDeliveryApp.domain;

public enum Role {
    USER,
    ADMIN,
    RESTAURANT
}
